import os

def extract_pk_files(directory):
    # 收集所有.pk文件的完整路径
    pk_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.pk'):
                pk_files.append(os.path.join(root, file))

    # 统计.pk文件数量
    total_pk_files = len(pk_files)
    print(f"Total .pk files found: {total_pk_files}")

    # 遍历.pk文件并进行解包
    for index, pk_file_path in enumerate(pk_files):
        # 显示进度
        progress = (index + 1) / total_pk_files * 100
        print(f"Progress: {progress:.2f}% - Current file: {os.path.basename(pk_file_path)}")

        # 调用解包工具，使用pk文件名
        os.system(f"LSPK-Extractor.exe \"{pk_file_path}\"")

    print("所有.pk文件均已处理.")

# 测试脚本
if __name__ == "__main__":
    directory_to_search = input("请输入一个有效的路径: ")
    extract_pk_files(directory_to_search)
